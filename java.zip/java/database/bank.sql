-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2024 at 07:39 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `amount`
--

CREATE TABLE `amount` (
  `id` int(16) NOT NULL,
  `balance` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `amount`
--

INSERT INTO `amount` (`id`, `balance`) VALUES
(1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` varchar(30) NOT NULL,
  `quantity` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `quantity`) VALUES
(1, 'rice', '200', '100'),
(3, 'pineaple', '200', '1000'),
(4, 'rice', '2332', '5667'),
(6, 'kkkk', '20', '500');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `amount` int(11) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `datedone` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`amount`, `type`, `datedone`) VALUES
(100, 'deposit', '2024-05-22 17:31:59'),
(200, 'deposit', '2024-05-22 17:32:46'),
(100, 'withdraw', '2024-05-22 17:32:53'),
(100, 'deposit', '2024-05-22 17:33:17'),
(200, 'withdraw', '2024-05-22 17:33:25'),
(100, 'deposit', '2024-05-22 17:36:10'),
(200, 'withdraw', '2024-05-22 17:36:25'),
(-500, 'withdraw', '2024-05-22 18:05:09'),
(600, 'withdraw', '2024-05-22 18:05:18'),
(-777, 'deposit', '2024-05-22 18:05:58'),
(1000, 'deposit', '2024-05-22 18:12:32'),
(10000, 'deposit', '2024-05-22 18:12:43'),
(1000, 'withdraw', '2024-05-22 18:12:51'),
(-400, 'deposit', '2024-05-22 18:20:33'),
(-500, 'deposit', '2024-05-22 18:20:44'),
(-7000, 'deposit', '2024-05-22 18:21:04'),
(-1, 'deposit', '2024-05-22 18:26:25'),
(-200, 'deposit', '2024-05-22 18:29:18'),
(-200, 'deposit', '2024-05-22 18:29:29'),
(300, 'withdraw', '2024-05-22 19:14:06'),
(200, 'withdraw', '2024-05-22 19:20:53'),
(1000, 'withdraw', '2024-05-22 19:21:01'),
(100, 'deposit', '2024-05-22 19:21:49'),
(1000, 'withdraw', '2024-05-22 19:21:55'),
(1000000, 'deposit', '2024-05-22 19:23:18'),
(10000, 'withdraw', '2024-05-22 19:23:26'),
(99999, 'withdraw', '2024-05-22 19:23:36'),
(890123, 'withdraw', '2024-05-22 19:23:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `amount`
--
ALTER TABLE `amount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `amount`
--
ALTER TABLE `amount`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
