
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
public class bankManagementSystem extends javax.swing.JFrame {

    public bankManagementSystem() {
        initComponents();
        connect();
        fetch();
    }
    @SuppressWarnings("unchecked")
    public void fetch(){
        try {
            newBalance.setEditable(false);
            pst=conn.prepareStatement("Select balance from amount where id=?");
            pst.setInt(1, 1);
            ResultSet rs= pst.executeQuery();
            if(rs.next()){
                double newbalance=rs.getDouble("balance");
                newBalance.setText("frw"+String.valueOf(newbalance));
            }
        } catch (SQLException ex) {
            Logger.getLogger(bankManagementSystem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        newBalance = new javax.swing.JTextField();
        amount = new javax.swing.JTextField();
        withdraw = new javax.swing.JButton();
        deposit = new javax.swing.JButton();
        Transaction = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        viewTransaction = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Bank management system");
        setBackground(new java.awt.Color(102, 255, 0));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Banking Application");

        newBalance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newBalanceActionPerformed(evt);
            }
        });

        amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                amountActionPerformed(evt);
            }
        });
        amount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                amountKeyPressed(evt);
            }
        });

        withdraw.setBackground(new java.awt.Color(204, 255, 0));
        withdraw.setText("Withdraw");
        withdraw.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        withdraw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                withdrawActionPerformed(evt);
            }
        });

        deposit.setBackground(new java.awt.Color(204, 255, 204));
        deposit.setText("Deposit");
        deposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                depositActionPerformed(evt);
            }
        });

        Transaction.setBackground(new java.awt.Color(153, 255, 204));
        Transaction.setText("View Transactions");
        Transaction.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Transaction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TransactionActionPerformed(evt);
            }
        });

        viewTransaction.setBackground(new java.awt.Color(255, 204, 255));
        viewTransaction.setColumns(20);
        viewTransaction.setRows(5);
        jScrollPane1.setViewportView(viewTransaction);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(183, 183, 183)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(amount, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(deposit, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(57, 57, 57)
                                .addComponent(withdraw, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(newBalance, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Transaction, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(amount, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(withdraw, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deposit, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addComponent(Transaction, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(newBalance, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void amountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_amountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_amountActionPerformed

    private void depositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_depositActionPerformed
        // TODO add your handling code here:
    String a = amount.getText();
    
    if (a.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Fill the field please");
        return;
    }

    double b;
    b = Double.parseDouble(a);
//    try {
//        b = Double.parseDouble(a);
//    } catch (NumberFormatException e) {
//        JOptionPane.showMessageDialog(this, "Please enter a valid ammount");
//        return;
//    }

    if (b <= 0) {
        JOptionPane.showMessageDialog(this, "Amount should be greater than 0");
        return;
    }

    try {
        pst = conn.prepareStatement("UPDATE amount SET balance = balance + ? WHERE id = ?");
        pst.setDouble(1, b);
        pst.setInt(2, 1);
        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Deposit successful");
        amount.setText("");

        
        newBalance.setEditable(false);
        pst = conn.prepareStatement("SELECT balance FROM amount WHERE id = ?");
        pst.setInt(1, 1);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            double newBalanceAmount = rs.getDouble("balance");
            newBalance.setText("frw " + newBalanceAmount);
        }

        
        pst = conn.prepareStatement("INSERT INTO transaction (amount, type, datedone) VALUES (?, 'deposit', NOW())");
        pst.setDouble(1, b);
        pst.executeUpdate();

        } catch (SQLException ex) {
           Logger.getLogger(bankManagementSystem.class.getName()).log(Level.SEVERE, null, ex);
         }
    }//GEN-LAST:event_depositActionPerformed

    private void withdrawActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_withdrawActionPerformed
        // TODO add your handling code here:
        String a = amount.getText();

    if (a.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Fill the field please");
        return;
    }

    double b;
    try {
        b = Double.parseDouble(a);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid number");
        return;
    }

    if (b <= 0) {
        JOptionPane.showMessageDialog(this, "Amount must be greater than 0");
        return;
    }

    try {
        // Check current balance
        pst = conn.prepareStatement("SELECT balance FROM amount WHERE id = ?");
        pst.setInt(1, 1);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            double currentBalance = rs.getDouble("balance");
            if (b > currentBalance) {
                JOptionPane.showMessageDialog(this, "Insufficient balance");
                return;
            }
        }

        // Update balance
        String sql = "UPDATE amount SET balance = balance - ? WHERE id = ?";
        pst = conn.prepareStatement(sql);
        pst.setDouble(1, b);
        pst.setInt(2, 1);
        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Withdrawal successful");
        amount.setText("");

        // Fetch new balance
        newBalance.setEditable(false);
        pst = conn.prepareStatement("SELECT balance FROM amount WHERE id = ?");
        pst.setInt(1, 1);
        ResultSet rss = pst.executeQuery();

        if (rss.next()) {
            double newBalanceAmount = rss.getDouble("balance");
            newBalance.setText("frw " + newBalanceAmount);
        }

        // Insert transaction record
        pst = conn.prepareStatement("INSERT INTO transaction (amount, type, datedone) VALUES (?, 'withdraw', NOW())");
        pst.setDouble(1, b);
        pst.executeUpdate();

    } catch (SQLException ex) {
        Logger.getLogger(bankManagementSystem.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_withdrawActionPerformed

    private void newBalanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newBalanceActionPerformed
        try {
            // TODO add your handling code here:
            newBalance.setEditable(false);
            pst=conn.prepareStatement("Select balance from amount where id=?");
            pst.setInt(1, 1);
            ResultSet rs= pst.executeQuery();
            if(rs.next()){
                double newbalance=rs.getDouble("balance");
                newBalance.setText("frw"+String.valueOf(newbalance));
            }
        } catch (SQLException ex) {
            Logger.getLogger(bankManagementSystem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_newBalanceActionPerformed

    private void amountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountKeyPressed
        // TODO add your handling code here:
        //JFrame validate=new JFrame();
        char valid=evt.getKeyChar();
        if(Character.isAlphabetic(valid)){
           JOptionPane.showMessageDialog(this, "Enter numeric values"); 
           amount.setText("");
        }
    }//GEN-LAST:event_amountKeyPressed

    private void TransactionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TransactionActionPerformed

        try {
        String sql = "SELECT amount, type, datedone FROM transaction";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        StringBuilder result = new StringBuilder();  

        // Header row with titles (adjust column names as needed)
        result.append(String.format("%-30s %-30s %-30s\n", "Amount", "Type", "Date"));

        while (rs.next()) {
            double amount = rs.getDouble("amount");
            String type = rs.getString("type");
            String datedone = rs.getString("datedone");

            // Format and append each transaction record with padding
            result.append(String.format("%-30.2f %-30s %-30s\n", amount, type, datedone));
        }

        viewTransaction.setText(result.toString());
        viewTransaction.setEditable(false);
        rs.close();
        pst.close();
    } catch (SQLException ex) {
        Logger.getLogger(bankManagementSystem.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_TransactionActionPerformed

    Connection conn;
    PreparedStatement pst;
    public void connect(){
        String URL= "jdbc:mariadb://localhost:3306/bank";
        String USERNAME= "root";
        String PASSWORD= "";
        try{
            Class.forName("org.mariadb.jdbc.Driver");
            conn=DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.print("connected");
        }
        catch(Exception e){
            e.getMessage();
        }
    }
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new bankManagementSystem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Transaction;
    private javax.swing.JTextField amount;
    private javax.swing.JButton deposit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField newBalance;
    private javax.swing.JTextArea viewTransaction;
    private javax.swing.JButton withdraw;
    // End of variables declaration//GEN-END:variables
}
